package minicompilateur11;

import java.util.List;
import java.util.ArrayList;

public class AnalyseurSyntaxique {
    private List<Token> tokens;
    private int position;
    private List<String> erreurs;
    private Token tokenCourant;

    public AnalyseurSyntaxique(List<Token> tokens) {
        this.tokens = tokens;
        this.position = 0;
        this.erreurs = new ArrayList<>();
        if (!tokens.isEmpty()) tokenCourant = tokens.get(0);
    }

    private void avancer() {
        position++;
        tokenCourant = position < tokens.size() ? tokens.get(position) : null;
    }

    public void analyser() {
        while (tokenCourant != null) {
            if (!Instruction()) avancer();
        }

        if (erreurs.isEmpty()) System.out.println("Analyse syntaxique réussie !");
    }

    private boolean Instruction() {
        if (tokenCourant == null) return false;

        if (estTypeVariable()) return Declaration();
        if (tokenCourant.type.equals("IDENTIFIANT")) return Affectation();
        if (tokenCourant.valeur.equals("while")) return WhileBoucle();
        if (tokenCourant.valeur.equals("for") || tokenCourant.valeur.equals("if") ||
            tokenCourant.valeur.equals("do") || tokenCourant.valeur.equals("else") ||
            tokenCourant.valeur.equals("switch") || tokenCourant.valeur.equals("case") ||
            tokenCourant.valeur.equals("break")) {
            ignorerInstruction(); return true;
        }

        if (tokenCourant.type.equals("ACCOLADE_FERM")) { avancer(); return true; }

        return false;
    }

    private boolean Declaration() {
        Token debut = tokenCourant;
        avancer();
        if (tokenCourant == null || !tokenCourant.type.equals("IDENTIFIANT")) {
            ajouterErreur("Nom de variable attendu après le type", tokenCourant);
            return false;
        }
        avancer();
        if (tokenCourant != null && tokenCourant.type.equals("OP_AFFECTATION")) { avancer(); if (!Expression()) return false; }
        if (tokenCourant == null || !tokenCourant.type.equals("POINT_VIRGULE")) { ajouterErreur("';' attendu", tokenCourant); return false; }
        avancer();
        return true;
    }

    private boolean Affectation() {
        Token debut = tokenCourant; avancer();
        if (tokenCourant != null && (tokenCourant.type.equals("OP_INCREMENT") || tokenCourant.type.equals("OP_DECREMENT"))) {
            avancer();
            if (tokenCourant == null || !tokenCourant.type.equals("POINT_VIRGULE")) { ajouterErreur("';' attendu", tokenCourant); return false; }
            avancer(); return true;
        }
        if (tokenCourant == null || !tokenCourant.type.equals("OP_AFFECTATION")) { ajouterErreur("'=' attendu", tokenCourant); return false; }
        avancer(); if (!Expression()) return false;
        if (tokenCourant == null || !tokenCourant.type.equals("POINT_VIRGULE")) { ajouterErreur("';' attendu", tokenCourant); return false; }
        avancer(); return true;
    }

    private boolean WhileBoucle() {
        avancer();
        if (tokenCourant == null || !tokenCourant.type.equals("PAREN_OUV")) { ajouterErreur("'(' attendu", tokenCourant); return false; }
        avancer();
        if (!ExpressionLogique()) return false;
        if (tokenCourant == null || !tokenCourant.type.equals("PAREN_FERM")) { ajouterErreur("')' attendu", tokenCourant); return false; }
        avancer(); return BlocOuInstruction();
    }

    private boolean ExpressionLogique() { return Expression(); }

    private boolean Expression() { 
        if (tokenCourant == null) { ajouterErreur("Expression attendue", null); return false; }
        if (tokenCourant.type.equals("NOMBRE") || tokenCourant.type.equals("IDENTIFIANT")) { avancer(); return true; }
        if (tokenCourant.type.equals("PAREN_OUV")) { avancer(); if (!Expression()) return false; if (tokenCourant == null || !tokenCourant.type.equals("PAREN_FERM")) { ajouterErreur("')' attendu", tokenCourant); return false; } avancer(); return true; }
        ajouterErreur("Expression invalide", tokenCourant); return false;
    }

    private boolean BlocOuInstruction() {
        if (tokenCourant != null && tokenCourant.type.equals("ACCOLADE_OUV")) {
            avancer();
            while (tokenCourant != null && !tokenCourant.type.equals("ACCOLADE_FERM")) Instruction();
            if (tokenCourant == null || !tokenCourant.type.equals("ACCOLADE_FERM")) { ajouterErreur("'}' attendu", tokenCourant); return false; }
            avancer(); return true;
        }
        return Instruction();
    }

    private boolean estTypeVariable() {
        return tokenCourant != null && ("int".equals(tokenCourant.valeur) || "float".equals(tokenCourant.valeur) ||
                "char".equals(tokenCourant.valeur) || "double".equals(tokenCourant.valeur));
    }

    private void ignorerInstruction() {
        int niveau = 0;
        while (tokenCourant != null) {
            if (tokenCourant.type.equals("ACCOLADE_OUV")) { niveau++; avancer(); }
            else if (tokenCourant.type.equals("ACCOLADE_FERM")) { if (niveau > 0) { niveau--; avancer(); if (niveau==0) break; } else break; }
            else if (tokenCourant.type.equals("POINT_VIRGULE") && niveau==0) { avancer(); break; }
            else avancer();
        }
    }

    private void ajouterErreur(String msg, Token t) {
        String e = "Erreur syntaxique";
        if (t != null) e += " ligne " + t.ligne + " : " + msg + " (trouvé : '" + t.valeur + "')";
        else e += " : " + msg + " (fin de fichier)";
        erreurs.add(e);
        System.out.println(e);
    }

    public List<String> getErreurs() { return erreurs; }
}
