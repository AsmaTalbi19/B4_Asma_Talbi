package minicompilateur11;

import java.util.ArrayList;
import java.util.List;

public class AnalyseurLexical {
    private String code;           // Code source à analyser
    private int position;          // Position actuelle dans le code
    private int ligne;             // Ligne actuelle
    private List<Token> tokens;    // Liste des tokens trouvés
    private List<String> erreurs;  // Liste des erreurs
    
    // Mots-clés du langage Java simplifié
    private String[] motsCles = {
        "int", "float", "char", "double", "void",
        "if", "else", "while", "do", "for",
        "return", "break", "continue", "boolean"
    };
    
    // Mots-clés personnalisés
    private String[] motsClesPerso = {
         "Asma", "Talbi"
    };
    
    public AnalyseurLexical(String code) {
        this.code = code;
        this.position = 0;
        this.ligne = 1;
        this.tokens = new ArrayList<>();
        this.erreurs = new ArrayList<>();
    }
    
    public void analyser() {
        while (position < code.length()) {
            char c = code.charAt(position);
            
            if (c == ' ' || c == '\t' || c == '\r') {
                position++;
                continue;
            }
            
            if (c == '\n') {
                ligne++;
                position++;
                continue;
            }
            
            if (c == '/' && position + 1 < code.length()) {
                if (code.charAt(position + 1) == '/') {
                    ignorerCommentaireLigne();
                    continue;
                } else if (code.charAt(position + 1) == '*') {
                    ignorerCommentaireBloc();
                    continue;
                }
            }
            
            if (Character.isLetter(c) || c == '_') {
                lireIdentifiant();
                continue;
            }
            
            if (Character.isDigit(c)) {
                lireNombre();
                continue;
            }
            
            if (reconnaitreOperateur()) {
                continue;
            }
            
            erreurs.add("Erreur lexicale ligne " + ligne + " : caractère invalide '" + c + "'");
            position++;
        }
    }
    
    private void ignorerCommentaireLigne() {
        while (position < code.length() && code.charAt(position) != '\n') {
            position++;
        }
    }
    
    private void ignorerCommentaireBloc() {
        position += 2;
        while (position < code.length() - 1) {
            if (code.charAt(position) == '\n') ligne++;
            if (code.charAt(position) == '*' && code.charAt(position + 1) == '/') {
                position += 2;
                return;
            }
            position++;
        }
        erreurs.add("Erreur lexicale ligne " + ligne + " : commentaire non fermé");
    }
    
    private void lireIdentifiant() {
        int debut = position;
        while (position < code.length() && 
               (Character.isLetterOrDigit(code.charAt(position)) || code.charAt(position) == '_')) {
            position++;
        }
        String mot = code.substring(debut, position);
        
        String type = "IDENTIFIANT";
        for (String mc : motsCles) {
            if (mot.equals(mc)) {
                type = "MOT_CLE";
                break;
            }
        }
        
        for (String mcp : motsClesPerso) {
            if (mot.equals(mcp)) {
                type = "MOT_CLE_PERSO";
                break;
            }
        }
        
        tokens.add(new Token(type, mot, ligne));
    }
    
    private void lireNombre() {
        int debut = position;
        while (position < code.length() && Character.isDigit(code.charAt(position))) {
            position++;
        }
        
        if (position < code.length() && code.charAt(position) == '.') {
            position++;
            while (position < code.length() && Character.isDigit(code.charAt(position))) {
                position++;
            }
        }
        
        String nombre = code.substring(debut, position);
        tokens.add(new Token("NOMBRE", nombre, ligne));
    }
    
    private boolean reconnaitreOperateur() {
        char c = code.charAt(position);
        
        if (position + 1 < code.length()) {
            String deuxChar = "" + c + code.charAt(position + 1);
            switch (deuxChar) {
                case "==":
                    tokens.add(new Token("OP_COMPARAISON", "==", ligne)); position += 2; return true;
                case "!=":
                    tokens.add(new Token("OP_COMPARAISON", "!=", ligne)); position += 2; return true;
                case "<=":
                    tokens.add(new Token("OP_COMPARAISON", "<=", ligne)); position += 2; return true;
                case ">=":
                    tokens.add(new Token("OP_COMPARAISON", ">=", ligne)); position += 2; return true;
                case "&&":
                    tokens.add(new Token("OP_LOGIQUE", "&&", ligne)); position += 2; return true;
                case "||":
                    tokens.add(new Token("OP_LOGIQUE", "||", ligne)); position += 2; return true;
                case "++":
                    tokens.add(new Token("OP_INCREMENT", "++", ligne)); position += 2; return true;
                case "--":
                    tokens.add(new Token("OP_DECREMENT", "--", ligne)); position += 2; return true;
            }
        }
        
        switch (c) {
            case '+': tokens.add(new Token("OP_ARITHMETIQUE", "+", ligne)); position++; return true;
            case '-': tokens.add(new Token("OP_ARITHMETIQUE", "-", ligne)); position++; return true;
            case '*': tokens.add(new Token("OP_ARITHMETIQUE", "*", ligne)); position++; return true;
            case '/': tokens.add(new Token("OP_ARITHMETIQUE", "/", ligne)); position++; return true;
            case '%': tokens.add(new Token("OP_ARITHMETIQUE", "%", ligne)); position++; return true;
            case '=': tokens.add(new Token("OP_AFFECTATION", "=", ligne)); position++; return true;
            case '<': tokens.add(new Token("OP_COMPARAISON", "<", ligne)); position++; return true;
            case '>': tokens.add(new Token("OP_COMPARAISON", ">", ligne)); position++; return true;
            case '!': tokens.add(new Token("OP_LOGIQUE", "!", ligne)); position++; return true;
            case '(': tokens.add(new Token("PAREN_OUV", "(", ligne)); position++; return true;
            case ')': tokens.add(new Token("PAREN_FERM", ")", ligne)); position++; return true;
            case '{': tokens.add(new Token("ACCOLADE_OUV", "{", ligne)); position++; return true;
            case '}': tokens.add(new Token("ACCOLADE_FERM", "}", ligne)); position++; return true;
            case ';': tokens.add(new Token("POINT_VIRGULE", ";", ligne)); position++; return true;
            case ',': tokens.add(new Token("VIRGULE", ",", ligne)); position++; return true;
        }
        
        return false;
    }
    
    public List<Token> getTokens() {
        return tokens;
    }
    
    public List<String> getErreurs() {
        return erreurs;
    }
    
    public void afficherTokens() {
        System.out.println("\n=== ANALYSE LEXICALE ===");
        System.out.println("Nombre de tokens trouvés : " + tokens.size());
        for (Token token : tokens) {
            System.out.println(token);
        }
    }
    
    public void afficherErreurs() {
        if (!erreurs.isEmpty()) {
            System.out.println("\n=== ERREURS LEXICALES ===");
            for (String erreur : erreurs) {
                System.out.println(erreur);
            }
        }
    }
}
