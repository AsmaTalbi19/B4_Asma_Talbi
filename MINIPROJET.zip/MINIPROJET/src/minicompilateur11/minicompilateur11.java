package minicompilateur11;

import java.util.List;
import java.util.Scanner;

public class minicompilateur11 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choix;

        do {
            System.out.println("===== MINI COMPILATEUR C =====");
            System.out.println("1 - Analyse lexicale (une ligne)");
            System.out.println("2 - Analyse syntaxique (plusieurs lignes)");
            System.out.println("0 - Quitter");
            System.out.print("Votre choix : ");

            while (!sc.hasNextInt()) { sc.nextLine(); System.out.print("Entrez un nombre : "); }
            choix = sc.nextInt(); sc.nextLine();

            switch (choix) {
                case 1:
                    System.out.print("Entrez le code (une ligne) : ");
                    String codeLex = sc.nextLine();
                    AnalyseurLexical lexer1 = new AnalyseurLexical(codeLex);
                    lexer1.analyser();
                    List<Token> tokensLex = lexer1.getTokens();
                    System.out.println("Tokens trouvés :");
                    for (Token t : tokensLex) System.out.println(t);
                    if (!lexer1.getErreurs().isEmpty()) System.out.println("Erreurs : " + lexer1.getErreurs());
                    break;

                case 2:
                    System.out.println("Entrez le code (plusieurs lignes, terminez par ligne vide) :");
                    StringBuilder sb = new StringBuilder();
                    while (true) {
                        String line = sc.nextLine();
                        if (line.trim().isEmpty()) break;
                        sb.append(line).append("\n");
                    }
                    AnalyseurLexical lexer2 = new AnalyseurLexical(sb.toString());
                    lexer2.analyser();
                    AnalyseurSyntaxique parser = new AnalyseurSyntaxique(lexer2.getTokens());
                    parser.analyser();
                    if (!parser.getErreurs().isEmpty()) System.out.println("Erreurs syntaxiques : " + parser.getErreurs());
                    break;

                case 0: System.out.println("Au revoir !"); break;
                default: System.out.println("Choix invalide !"); break;
            }
            System.out.println();
        } while (choix != 0);

        sc.close();
    }
}
